/**
 * CurrentStatementWidgetType
 */
type CurrentStatementWidgetType = {
	status: string;
	date: string;
	limit: number;
	spent: number;
	minimum: number;
};

export default CurrentStatementWidgetType;

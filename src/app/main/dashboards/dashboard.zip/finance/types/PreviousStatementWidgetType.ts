/**
 * PreviousStatementWidgetType
 */
type PreviousStatementWidgetType = {
	status: string;
	date: string;
	limit: number;
	spent: number;
	minimum: number;
};

export default PreviousStatementWidgetType;
